# 论文框架文档

## 题目

**Temporal-Aware Flow Matching for Visuomotor Robot Policies via Self-Predictive Dynamics and Episodic Memory**

（基于自预测动力学与情景记忆的时间感知流匹配视觉运动机器人策略）

---

## 核心问题

标准的 flow matching 策略（如 VITA）在推理时是**无记忆的**——每步独立决策，无法感知"当前处于任务的哪个阶段"。这导致：
1. 多阶段任务（接近→跟踪）中，策略无法隐式区分不同阶段的行为模式
2. 无法适应当前 episode 的特定几何特征
3. 缺乏时间上下文，在弧线跟踪等高精度任务中精度不足

## 核心贡献

提出 **Past-Present-Future (PPF)** 时间感知框架，通过三个自监督模块为 flow matching 策略注入隐式时间意识：

1. **Self-Predictive Latent Dynamics（未来）**：学习预测下一步的观测潜变量，预测误差作为阶段转折的隐式指示器
2. **Progress Predictor + Dual FiLM（现在→全局）**：从特征差分+动力学误差自监督学习任务进度，通过 FiLM 双路调制注入 flow network
3. **Episodic Memory Bank（过去）**：轻量 key-value 记忆模块，推理时逐步积累观测历史，提供轨迹上下文

**完全自监督**，不需要任何人工标注的时间标签或阶段标签。

---

## 论文结构

### 1. Introduction（引言）
- 机器人模仿学习中 flow matching 的优势（多模态、高质量生成）
- 问题：无记忆、无时间感知 → 多阶段任务和精密跟踪场景下的局限
- 显式时间标注的不足（不泛化、需要人工设计）
- 提出 PPF 框架：过去-现在-未来 三维时间感知
- 贡献点总结

### 2. Related Work（相关工作）
- **2.1 Flow Matching for Robot Policies**: VITA, Diffusion Policy, pi-0, 等
- **2.2 Temporal Encoding in Imitation Learning**: obs_horizon stacking, TCN, 时间对比学习
- **2.3 Memory-Augmented Policies**: 记忆增强网络, 外部记忆, Transformer 中的 KV-cache
- **2.4 Self-Predictive Learning**: BYOL, VICReg, 前向动力学模型

### 3. Preliminaries（预备知识）
- **3.1 Optimal Transport Conditional Flow Matching (OT-CFM)**
- **3.2 VITA Architecture**: obs_latent → flow → action_latent → action_decoder
- **3.3 FiLM Conditioning**

### 4. Method（方法）
- **4.1 Overview**: PPF 框架的整体架构图
- **4.2 Temporal Feature Differencing**:
  - 特征空间差分 Δf = f(obs_t) - f(obs_{t-1})
  - 状态差分 Δstate = state_t - state_{t-1}
  - 编码"语义速度"——区分接近阶段（快速、方向性强）vs 跟踪阶段（慢速、精细）
- **4.3 Self-Predictive Latent Dynamics**:
  - LatentDynamics 模型：从 obs_latent_t 预测 obs_latent_{t+1}
  - 预测误差 e_t = ||ô_{t+1} - o_t||² 作为阶段转折指示器
  - Stop-gradient self-prediction 避免表征坍缩
  - 损失函数 L_dynamics
- **4.4 Self-Supervised Progress Predictor**:
  - 输入：obs_latent + dynamics prediction error
  - 输出：p̂ ∈ [0, 1]（任务进度）
  - Ordinal ranking loss: 全局帧索引作为弱监督信号
  - 通过 sinusoidal embedding → FiLM 注入 flow network
  - Dual FiLM: flow timestep 和 task progress 分离调制
- **4.5 Episodic Memory Bank**:
  - 轻量 key-value attention 读取（非 full transformer）
  - 训练时：batch 内随机采样构造伪记忆
  - 推理时：逐步累积 obs_latent 形成真实记忆
  - memory_context 与 obs_latent 融合后作为 flow start
- **4.6 Joint Training Objective**:
  - L_total = L_flow + L_enc_recon + L_flow_recon + L_consistency + λ_dyn · L_dynamics + λ_prog · L_progress
  - 所有辅助损失均为自监督，不需要额外标注
  - 梯度分析：各模块如何互相促进

### 5. Experimental Setup（实验设置）
- **5.1 Task Description**:
  - MR2010 机器人 S-curve 焊缝跟踪（6-DOF 关节控制）
  - 两阶段任务：approach（接近焊缝起点）+ tracking（沿焊缝跟踪）
  - 工件位置随机化
- **5.2 Dataset**:
  - 204 条专家轨迹，每条 700 帧（approach 200 + tracking 500）
  - 观测：2 个摄像头（overhead, ee_cam）480×640 + 6 维关节角
  - 动作：6 维关节绝对位置
- **5.3 Baselines**:
  - VITA (原始): 无时间感知
  - VITA + obs_horizon=2: 简单帧堆叠
  - VITA + explicit progress: 显式注入 t/T
  - ACT (Action Chunking Transformer): 作为架构级对比
- **5.4 Evaluation Metrics**:
  - Approach success rate (%)
  - Mean/Max/Median tracking distance (mm)
  - Multi-level coverage: <0.5mm, <1mm, <2mm, <5mm
  - Reward level distribution (S/A/B/C/D/E/FAIL)
- **5.5 Implementation Details**:
  - latent_dim=512, flow_layers=4, chunk_size=16, action_horizon=4
  - num_sampling_steps=10, training steps=200k
  - dynamics_weight=0.5, progress_weight=0.1, memory_size=8
  - AdamW, cosine LR with 500 warmup, EMA power=0.75

### 6. Results（实验结果）
- **6.1 Main Results**: PPF vs baselines 的定量对比表
- **6.2 Ablation Study**:
  - (a) 只有 Dynamics（无 Progress, 无 Memory）
  - (b) 只有 Progress（无 Dynamics, 无 Memory）
  - (c) 只有 Memory（无 Dynamics, 无 Progress）
  - (d) Dynamics + Progress（无 Memory）
  - (e) Dynamics + Memory（无 Progress）
  - (f) 完整 PPF
- **6.3 Progress Prediction Analysis**:
  - 可视化 progress 随帧数的变化曲线
  - 验证 approach 阶段 progress 低、tracking 阶段 progress 高
  - 不同 episode 的 progress 曲线对比
- **6.4 Memory Attention Analysis**:
  - 可视化 memory attention weights
  - 验证策略关注了哪些历史帧
- **6.5 Dynamics Error Analysis**:
  - 可视化 prediction error 随时间的变化
  - 验证 approach→tracking 转折点处误差峰值
- **6.6 Generalization**: 在未见过的工件位置上的泛化能力

### 7. Discussion（讨论）
- PPF 的适用范围和局限性
- 与 Transformer-based TTT 的对比
- 计算开销分析（参数量、推理速度）
- 未来方向：真实机器人部署、更复杂的多阶段任务

### 8. Conclusion（结论）
- 总结 PPF 框架的核心思想和实验结果
- 强调自监督、无需人工标注的优势

---

## 所需实验

| 实验 | 训练命令 | 备注 |
|------|---------|------|
| Baseline (VITA) | `--policy vita --steps 200000` | 无时间感知 |
| PPF (完整) | `--policy vita --steps 200000 --use_temporal` | 所有模块 |
| Ablation: only dynamics | 需要代码开关 | 关闭 progress + memory |
| Ablation: only progress | 需要代码开关 | 关闭 dynamics + memory |
| Ablation: only memory | 需要代码开关 | 关闭 dynamics + progress |
| obs_horizon=2 | `--policy vita --steps 200000 --obs_horizon 2` | 简单帧堆叠 |

## 所需图表

| 图号 | 内容 | 类型 |
|------|------|------|
| Fig.1 | PPF 整体架构图 | 系统框图 |
| Fig.2 | 焊缝跟踪任务示意图 | 3D 场景图 |
| Fig.3 | Temporal Feature Differencing 示意 | 数据流图 |
| Fig.4 | Dual FiLM 调制机制 | 模块细节图 |
| Fig.5 | Progress 预测曲线 | 折线图 |
| Fig.6 | Memory Attention 热力图 | 热力图 |
| Fig.7 | Dynamics Error 时间曲线 | 折线图 |
| Fig.8 | 跟踪轨迹对比（PPF vs Baseline） | 3D 轨迹图 |
| Tab.1 | Main Results | 表格 |
| Tab.2 | Ablation Study | 表格 |
| Tab.3 | 计算开销对比 | 表格 |
